#for config use
from _logger import *
#for logger use
from _logger import LOGGER
