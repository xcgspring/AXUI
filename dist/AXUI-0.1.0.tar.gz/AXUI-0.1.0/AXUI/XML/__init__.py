#used by config module
from XML_config import *
#app map interface
from app_map import AppMap